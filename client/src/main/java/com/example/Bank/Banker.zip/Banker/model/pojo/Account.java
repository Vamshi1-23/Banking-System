package com.example.Bank.Banker.model.pojo;

import java.util.List;

public class Account {
	private String accNo;
	private double balance;
	private List<Transactions> transactions;
	private Branch ifsc;

	public Account(String accId, double balance, List<Transactions> transactions, Branch branchId) {
		super();
		this.accNo = accId;
		this.balance = balance;
		this.transactions = transactions;
		this.ifsc = branchId;
	}

	public Account() {
		super();
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accId) {
		this.accNo = accId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<Transactions> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transactions> transactions) {
		this.transactions = transactions;
	}

	public Branch getIfsc() {
		return ifsc;
	}

	public void setIfsc(Branch ifsc) {
		this.ifsc = ifsc;
	}

}
