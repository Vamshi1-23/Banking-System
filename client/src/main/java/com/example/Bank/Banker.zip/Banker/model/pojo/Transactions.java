package com.example.Bank.Banker.model.pojo;

public class Transactions {
	private String transId;
	private String transType;
	private Account accId;

	public Transactions(String transId, String transType, Account accId) {
		super();
		this.transId = transId;
		this.transType = transType;
		this.accId = accId;
	}

	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public Account getAccId() {
		return accId;
	}

	public void setAccId(Account accId) {
		this.accId = accId;
	}

}
