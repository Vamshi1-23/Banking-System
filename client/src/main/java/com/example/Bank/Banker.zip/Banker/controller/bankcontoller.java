package com.example.Bank.Banker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Bank.Banker.model.pojo.Admin;
import com.example.Bank.Banker.model.pojo.Branch;
import com.example.Bank.Banker.model.serviceimpl.BankServiceimpl;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;

@Controller
public class bankcontoller {
	@Autowired
	BankServiceimpl bankimpl;

	//----------------------------------------Admin-----------------------------------------------------//
	
	@RequestMapping("/a")
	public String set() {
		return "insertAdmin";
	}

	@RequestMapping("/insertAdmin")
	public String insertAdmin(Model m, @ModelAttribute("A") Admin admin) {
		m.addAttribute("msg", bankimpl.insertAdmin(admin));
		return "insertAdmin";

	}

	@RequestMapping("/aa")
	public String set1(Model m) {

		return "updateAdmin";
	}

	@RequestMapping("/updateAdmin")
	public String updateAdmin(Model m, @ModelAttribute("S") Admin admin, @RequestParam("s") String adminid) {
		m.addAttribute("msg1", bankimpl.updateAdmin(admin, adminid));
		return "updateAdmin";
	}
	
	
	//----------------------------------------------Branches--------------------------------------------------------//

	@RequestMapping("/b")
	public String br() {
		return "insertBranch";
	}

	@RequestMapping("/insertBranch")
	public String insertBranch(Model m, @ModelAttribute("A") Branch branch) {
		m.addAttribute("msg", bankimpl.insertBranch(branch));
		return "insertBranch";

	}

	@RequestMapping("/bb")
	public String bran(Model m,Branch branch) {
		m.addAttribute("bb",bankimpl.Allbranches());
		return "deleteBranch";
	}
	@RequestMapping("/delete")
	public String deleteBranch(Model m, @ModelAttribute("S") Branch branch) {
		m.addAttribute("msg",bankimpl.deleteBranch(branch));
		return "deleteBranch";

	}
	@RequestMapping("/bbb")
	public String getallbranches(Model M)
	{
		M.addAttribute("msg",bankimpl.Allbranches());
		return "Allbranches";
	}

}
