package com.example.Bank.Banker.model.pojo;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class NewUser {
	private String newUserId;
	private String fName;

	private String lName;

	private String email;

	private String gender;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;

	private String phNo;

	private String nationality;

	private String pancard;

	private String Aadhar;

	private String address;

	private String branchLocation;

	public NewUser(String newUserId, String fName, String lName, String email, String gender, LocalDate dob,
			String phNo, String nationality, String pancard, String aadhar, String address, String branchLocation) {
		super();
		this.newUserId = newUserId;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.gender = gender;
		this.dob = dob;
		this.phNo = phNo;
		this.nationality = nationality;
		this.pancard = pancard;
		Aadhar = aadhar;
		this.address = address;
		this.branchLocation = branchLocation;
	}

	public NewUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNewUserId() {
		return newUserId;
	}

	public void setNewUserId(String newUserId) {
		this.newUserId = newUserId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getPhNo() {
		return phNo;
	}

	public void setPhNo(String phNo) {
		this.phNo = phNo;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public String getAadhar() {
		return Aadhar;
	}

	public void setAadhar(String aadhar) {
		Aadhar = aadhar;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBranchLocation() {
		return branchLocation;
	}

	public void setBranchLocation(String branchLocation) {
		this.branchLocation = branchLocation;
	}

}
