package com.example.Bank.Banker.model.serviceimpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;
import com.example.Bank.Banker.model.pojo.Admin;
import com.example.Bank.Banker.model.pojo.Branch;

public class BankServiceimpl {
	@Autowired
	RestTemplate rest;
	public String url = "http://localhost:9991/";

	public String insertAdmin(Admin admin) {
		String Admin = rest.postForObject(url + "insertAdmin", admin, String.class);
		return Admin;
	}

	public String updateAdmin(Admin admin, String id) {
		rest.put(url + "updateAdmin/" + id, admin);
		return "Adminupdated";
	}

	public String insertBranch(Branch branch) {
		String Branch = rest.postForObject(url + "insertBranch", branch, String.class);
		return Branch;
	}

	public String deleteBranch(Branch branch) {
		rest.delete(url + "deletebranch/");
		return "Branchdeleted";
	}

	public List<Branch> Allbranches() {
		Branch branches = rest.getForObject(url + "get", Branch.class);
		return Arrays.asList(branches);

	}

}
